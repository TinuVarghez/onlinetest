<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
   <div class="container">
    <div class="navigation">
       <ul>
        <li>
            <a href="">
                <span class="title">&nbsp;&nbsp;Online Test Appointment & Results</span>
            </a>
        </li>
        <li>
            <a href="">
                <span class="icon"></span>
                <span class="title">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="appoint.php">
                <span class="icon"><ion-icon name="eyedrop-outline"></ion-icon></span>
                <span class="title">Test Appointment</span>
            </a>
        </li>
        <li class="active">
            <a href="result.php">
                <span class="icon"><ion-icon name="newspaper-outline"></ion-icon></span>
                <span class="title">View Results</span>
            </a>
        </li>
        <li>
            <a href="createu.php">
                <span class="icon"><ion-icon name="construct-outline"></ion-icon></span>
                <span class="title">Feedback</span>
            </a>
        </li>
        <li>
            <a href="updateu.php">
                <span class="icon"><ion-icon name="bag-add-outline"></ion-icon></span>
                <span class="title">Update Key</span>
            </a>
        </li>
        <li>
            <a onclick="signout()">
                <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                <span class="title">Sign Out</span>
            </a>
        </li>
       </ul> 
    </div>
   </div>
   <div class="main">
   <div class="user">
   <img src="images/user1.png">
   </div>
   </div>
   <?php 
   session_start(); 
   $cr=$_SESSION['name'];
   include_once("config.php");
   $result = mysqli_query($mysqli, "SELECT * FROM appoint, result WHERE appoint.Creator = 'tv' AND appoint.Tid = result.Tid");
   ?>
   <div class="header_fixed">
    <h4>Updated Results</h4>
    <table>
    <thead>
        <tr>
            <th>Ticket No<th>Name</th><th>Age</th><th>Gender</th><th>Date</th><th>Results</th>
        </tr>
    </thead>
    <tbody>
        <?php
        while($user_data = mysqli_fetch_array($result)) 
        {
            echo "<tr>";
            echo "<td>".$user_data['Tid']."</td>";
            echo "<td>".$user_data['Name']."</td>";
            echo "<td>".$user_data['Age']."</td>";
            echo "<td>".$user_data['Gender']."</td>";
            echo "<td>".$user_data['Date']."</td>";
            echo "<td>";
            if($user_data['Owner']!='')
            {
            echo "<br><br>CBC:".$user_data['CBC'];
            echo "<br><br>Cholesterol:".$user_data['Cholesterol'];
            echo "<br><br>Sugar:".$user_data['Sugar'];
            echo"</td>";
            }
            else
            {
                echo "Result Not Uploaded!!";
            }
        }
        ?>
    </tbody>
        </table>
    </div>
   <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script>
    let list =document.querySelectorAll('.navigation li');
    function al()
    {
        list.forEach((item)=>
        item.classList.remove('hovered'));
        this.classList.add('hovered')
        list.forEach((item)=>
        item.addEventListener('mouseover',al));
    }
    function signout() {
    let text = "Are u sure!";
    if (confirm(text) == true) {
        window.location.href="login.php";
    }
    }
</script>
</body>
</html>