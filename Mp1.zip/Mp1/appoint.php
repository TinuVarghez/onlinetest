<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
   <div class="container">
    <div class="navigation">
       <ul>
        <li>
            <a href="">
                <span class="title">&nbsp;&nbsp;Online Test Appointment & Results</span>
            </a>
        </li>
        <li>
            <a href="">
                <span class="icon"></span>
                <span class="title">Dashboard</span>
            </a>
        </li>
        <li class="active">
            <a href="appoint.php">
                <span class="icon"><ion-icon name="eyedrop-outline"></ion-icon></span>
                <span class="title">Test Appointment</span>
            </a>
        </li>
        <li>
            <a href="result.php">
                <span class="icon"><ion-icon name="newspaper-outline"></ion-icon></span>
                <span class="title">View Results</span>
            </a>
        </li>
        <li>
            <a href="createu.php">
                <span class="icon"><ion-icon name="construct-outline"></ion-icon></span>
                <span class="title">Feedback</span>
            </a>
        </li>
        <li>
            <a href="updateu.php">
                <span class="icon"><ion-icon name="bag-add-outline"></ion-icon></span>
                <span class="title">Update Key</span>
            </a>
        </li>
        <li>
            <a onclick="signout()">
                <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                <span class="title">Sign Out</span>
            </a>
        </li>
       </ul> 
    </div>
   </div>
   <div class="main">
   <div class="user">
   <img src="images/user1.png">
   </div>
   </div>
   <div class="key">
    <h4>Fill Details</h4>
    <form action="" method="post">
    <label for="">Name</label><br><br>
    <input type="text" name="name" id="name" required><br><br>
    <label for="">Age</label><br><br>
    <input type="number" name="age" id="age" required><br><br>
    <label for="">Gender</label><br><br>
    <select name="la" id="la">
    <option value='M'>Male</option>
    <option value='F'>Female</option>
    <option value='O'>Others</option>
    </select><br><br>
    <label for="">Date & Time</label><br><br>
    <input type="datetime-local" name="date" id="date"><br><br>
    <label for="">Test Available</label><br><br>
    <input type="checkbox" name="test[]" value="b">
    <label for="cbc" class="checkbox-label">CBC</label>
    <input type="checkbox" name="test[]" value="c">
    <label for="cholesterol" class="checkbox-label">Cholesterol</label>
    <input type="checkbox" name="test[]" value="s">
    <label for="sugar" class="checkbox-label">Sugar</label><br><br>
    <button>Submit</button>
    </form>
    </div>
   <?php 
   session_start(); 
   $cr=$_SESSION['name'];
   include_once("config.php");
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $name=$_POST['name'];
   $age=$_POST['age'];
   $g=$_POST['la'];
   $date = $_POST['date'];
   $selectedtest = $_POST['test'];
   $tid = rand(100,200);
   $ct = implode(',', $selectedtest);

   $result = mysqli_query($mysqli, "INSERT INTO appoint VALUES($tid,'$name',$age,'$g','$date','$ct','$cr')");
   mysqli_query($mysqli, "INSERT INTO result(Tid) VALUES($tid)");

   if($result){
    echo '<script>alert("Submitted Successfully")</script>';
   }
   else{
    echo '<script>alert("Not Saved")</script>';
   }
   }
   ?>
   <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script>
    let list =document.querySelectorAll('.navigation li');
    function al()
    {
        list.forEach((item)=>
        item.classList.remove('hovered'));
        this.classList.add('hovered')
        list.forEach((item)=>
        item.addEventListener('mouseover',al));
    }
    function signout() {
    let text = "Are u sure!";
    if (confirm(text) == true) {
        window.location.href="login.php";
    }
    }
</script>
</body>
</html>