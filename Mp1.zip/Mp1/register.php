<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="login.css">
  <title>Login</title>
  <script>
        function C() {
            var o = document.getElementById("la");
            var SecretC = document.getElementById("SecretC");

            if (o.value === "A") {
                SecretC.style.display = "block";
            } else {
                SecretC.style.display = "none";
            }
        }
    </script>
</head>
<body>
    <section>
        <div class="form-box">
            <div class="form-value">
                <form action="" method="post">
                    <h2>Register</h2>
                    <div class="inputbox">
                        <ion-icon name="person-outline"></ion-icon>                      
                        <input type="text" name="user" id="user" required>
                        <label for="">User</label>
                    </div>
                    <div class="inputbox">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" name="pass" id="pass" required>
                        <label for="">New Password</label>
                    </div>
                    <div class="inputbox">
                        <ion-icon name="chevron-down-outline"></ion-icon>
                        <select name="la" id="la" onchange="C()">
                        <option value='A'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Admin</option>
                        <option value='U'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;User</option>
                        </select> 
                        <label for="">Logging as</label>                     
                    </div>
                    <div class="inputbox" id="SecretC">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" name="sc" id="sc">
                        <label for="">Secret Code</label>
                    </div>
                    <button>Register</button>
                    
                </form>
            </div>
        </div>
    </section>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>

<?php
include_once("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$user=$_POST['user'];
$pass=$_POST['pass'];
$role=$_POST['la'];
$sc=$_POST['sc'];
if($role=="A")
{
   if($sc=="123")
   {
   $result = mysqli_query($mysqli, "INSERT INTO main VALUES('$user','$pass','$role')");
   }
   else
   {
    echo '<script>alert("Wrong Secret Code");window.location.href="register.php";</script>';
   }
}
else
{
    $result = mysqli_query($mysqli, " INSERT INTO main VALUES('$user','$pass','$role')");
}
if($result){
    echo '<script>alert("Success");window.location.href="login.php";</script>';
}
else
{
    echo '<script>alert("Not Found!")</script>';
}
}
?>