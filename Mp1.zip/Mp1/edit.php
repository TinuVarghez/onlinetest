<?php
include_once("config.php");

$id = $_GET['id'];
$st = $_GET['st'];
$o=$_GET['cr'];

$result = mysqli_query($mysqli, "SELECT * FROM appoint WHERE Tid=$id");

while($user_data = mysqli_fetch_array($result))
{
	$name = $user_data['Name'];
	$age = $user_data['Age'];
	$g = $user_data['Gender'];
    $d = $user_data['Date'];
}
?>
<html>
<head>
	<title>Upload User Data</title>
    <style> 
    @import url('https://fonts.googleapis.com/css2?family=Ubuntu:wght@300;400;500;700&display=swap');
    *
    {
    margin: 0;
    padding: 0;
    font-family: 'Ubuntu',sans-serif; 
    color: red; 
    }
    table {
      margin-top: 50px;
      margin-left: 450px;
      width: 40%;
      font-size: 120%;
      border-spacing: 30px;
    }

    table tr, td {
      margin-bottom: 20px;
    }
    table input{
        width: 50%;
        height: 30px;
    }
    input[type="submit"]{
      width: 30%;
      margin-left: 65px;
      color: white;
      background-color: red;
      border-radius: 10px;
    }

    </style>
</head>

<body>
	<form method="post" action="">
		<table border="0" align="center">
			<tr>
				<td>Name:</td>
				<td><label><?php echo $name;?></td>
			</tr>
			<tr>
				<td>Age:</td>
				<td><label><?php echo $age;?></td>
			</tr>
			<tr>
				<td>Gender:</td>
				<td><label><?php echo $g;?></td>
			</tr>
            <tr>
				<td>Date:</td>
				<td><label><?php echo $d;?></td>
			</tr>
			<tr>
				<td>Pathology</td>
			</tr>
            <?php
            if (str_contains($st, 'b'))
            {
                echo "<tr>";
                echo"<td>CBC:</td>";
                echo"<td><input type='text' name='b'></td>";
                echo "</tr>";
            }
            if (str_contains($st,'c'))
            {
                echo "<tr>";
                echo"<td>Cholesterol:</td>";
                echo"<td><input type='text' name='c'></td>";
                echo "</tr>";
            }
            if (str_contains($st,'s'))
            {
                echo "<tr>";
                echo"<td>Sugar:</td>";
                echo"<td><input type='text' name='s'></td>";
                echo "</tr>";
            }
            ?>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
                <td><input type="hidden" name="cr" value=<?php echo $_GET['cr'];?>></td>
			</tr>
            <tr>
            <td></td>
            <td><input type="submit" name="Submit" value="Submit"></td>
            </tr>
		</table>
	</form>
</body>
</html>
<?php
include_once("config.php");

if($_SERVER["REQUEST_METHOD"] == "POST")
{
	$id = $_POST['id'];
	$o = $_POST['cr'];
	$b = isset($_POST['b']) ? $_POST['b'] : 0;
    $c = isset($_POST['c']) ? $_POST['c'] : 0;
    $s = isset($_POST['s']) ? $_POST['s'] : 0;
	$result = mysqli_query($mysqli, "UPDATE result SET CBC=$b,Cholesterol=$c,Sugar=$s,Owner='$o' where Tid=$id");
    if($result){
        echo '<script>alert("Updated Successfully");window.location.href="upload.php";</script>';
        mysqli_query($mysqli, "UPDATE appoint SET STest='' where Tid=$id");
    }  
}
?>
