<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
   <div class="container">
    <div class="navigation">
       <ul>
        <li>
            <a href="">
                <span class="title">&nbsp;&nbsp;Online Test Appointment & Results</span>
            </a>
        </li>
        <li>
            <a href="">
                <span class="icon"></span>
                <span class="title">Dashboard</span>
            </a>
        </li>
        <li>
            <a href="appoint.php">
                <span class="icon"><ion-icon name="eyedrop-outline"></ion-icon></span>
                <span class="title">Test Appointment</span>
            </a>
        </li>
        <li>
            <a href="result.php">
                <span class="icon"><ion-icon name="newspaper-outline"></ion-icon></span>
                <span class="title">View Results</span>
            </a>
        </li>
        <li>
            <a href="createu.php">
                <span class="icon"><ion-icon name="construct-outline"></ion-icon></span>
                <span class="title">Feedback</span>
            </a>
        </li>
        <li class="active">
            <a href="updateu.php">
                <span class="icon"><ion-icon name="bag-add-outline"></ion-icon></span>
                <span class="title">Update Key</span>
            </a>
        </li>
        <li>
            <a onclick="signout()">
                <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                <span class="title">Sign Out</span>
            </a>
        </li>
       </ul> 
    </div>
   </div>
   <div class="main">
   <div class="user">
   <img src="images/user1.png">
   </div>
   </div>
   <div class="key">
    <h4>Update Key</h4>
    <form action="" method="post">
        <label for="">Old Username</label><br><br>
        <input type="text" name="ouser" id="ouser" required><br><br>
        <label for="">Old Password</label><br><br>
        <input type="password" name="opass" id="opass" required><br><br>
        <label for="">New Username</label><br><br>
        <input type="text" name="nuser" id="nuser" required><br><br>
        <label for="">New Password</label><br><br>
        <input type="password" name="npass" id="npass" required><br><br>    
    <button>Apply</button>
    </form>
    </div>
   <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script>
    let list =document.querySelectorAll('.navigation li');
    function al()
    {
        list.forEach((item)=>
        item.classList.remove('hovered'));
        this.classList.add('hovered')
        list.forEach((item)=>
        item.addEventListener('mouseover',al));
    }
    function signout() {
    let text = "Are u sure!";
    if (confirm(text) == true) {
        window.location.href="login.php";
    }
    }
</script>
</body>
</html>
<?php
include_once("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$ouser=$_POST['ouser'];
$opass=$_POST['opass'];
$nuser=$_POST['nuser'];
$npass=$_POST['npass'];

$result = mysqli_query($mysqli, "UPDATE main SET Username='$nuser', Password='$npass' WHERE Role='U' AND Username='$ouser'AND Password='$opass'");
if($result){
    echo '<script>alert("Updated Successfully")</script>';
}
else{
    echo '<script>alert("Not Found!")</script>';
}
}
?>