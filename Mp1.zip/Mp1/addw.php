<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" type="text/css" href="main.css">
    
</head>
<body>
   <div class="container">
    <div class="navigation">
       <ul>
        <li>
            <a href="">
                <span class="title">Online Test Appointment & Results</span>
            </a>
        </li>
        <li>
            <a href="">
                <span class="icon"></span>
                <span class="title">Welcome,Sir&nbsp;Looking good!</span>
            </a>
        </li>
        <li class="active">
            <a href="addw.php">
                <span class="icon"><ion-icon name="person-add-outline"></ion-icon></ion-icon></span>
                <span class="title">Add Worker</span>
            </a>
        </li>
        <li>
            <a href="viewa.php">
                <span class="icon"><ion-icon name="eye-outline"></ion-icon></span>
                <span class="title">View Feedback</span>
            </a>
        </li>
        <li>
            <a href="updatea.php">
                <span class="icon"><ion-icon name="bag-add-outline"></ion-icon></span>
                <span class="title">Update Key</span>
            </a>
        </li>
        <li>
            <a onclick="signout()">
                <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                <span class="title">Sign Out</span>
            </a>
        </li>
       </ul> 
    </div>
   </div>
   <div class="main">
    <div class="user">
    <img src="images/admin1.png">
    </div>
    </div>
    <div class="key">
    <h4>Add Worker</h4>
    <form action="" method="post">
    <label for="">Username</label><br><br>
    <input type="text" name="user" id="user" required><br><br>
    <label for="">Password</label><br><br>
    <input type="pass" name="pass" id="pass" required><br><br>
    <button>Add</button>
    </form>
    </div>
   <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script>
    let list =document.querySelectorAll('.navigation li');
    function al()
    {
        list.forEach((item)=>
        item.classList.remove('hovered'));
        this.classList.add('hovered')
        list.forEach((item)=>
        item.addEventListener('mouseover',al));
    }
    function signout() {
    let text = "Are u sure!";
    if (confirm(text) == true) {
        window.location.href="login.php";
    }
    }
</script>
</body>
</html>
<?php
include_once("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$user=$_POST['user'];
$pass=$_POST['pass'];
$result = mysqli_query($mysqli, " INSERT INTO main VALUES('$user','$pass','W')");
if($result){
    echo '<script>alert("Success")</script>';
}
else
{
    echo '<script>alert("Not Found!")</script>';
}
}
?>