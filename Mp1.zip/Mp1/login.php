<!DOCTYPE html>
<html lang="en">
<head>
  <link rel="stylesheet" href="login.css">
  <title>Login</title>
</head>
<body>
    <section>
        <div class="form-box">
            <div class="form-value">
                <form action="" method="post">
                    <h2>Login</h2>
                    <div class="inputbox">
                        <ion-icon name="person-outline"></ion-icon>                      
                        <input type="text" name="user" id="user" required>
                        <label for="">User</label>
                    </div>
                    <div class="inputbox">
                        <ion-icon name="lock-closed-outline"></ion-icon>
                        <input type="password" name="pass" id="pass" required>
                        <label for="">Password</label>
                    </div>
                    <div class="inputbox">
                        <ion-icon name="chevron-down-outline"></ion-icon>
                        <select name="la" id="la">
                        <option value='A'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Admin</option>
                        <option value='W'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Worker</option>
                        <option value='U'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;User</option>
                        </select> 
                        <label for="">Logging as</label>                     
                    </div>
                    <button>Log in</button>
                    <div class="register">
                        <p>Don't have a account? <a href="register.php">Register</a></p>
                    </div>
                </form>
            </div>
        </div>
    </section>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>

<?php
include_once("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
$user=$_POST['user'];
$pass=$_POST['pass'];
$role=$_POST['la'];
session_start(); 
$_SESSION['name'] = $_POST['user']; 

$result = mysqli_query($mysqli, "SELECT * FROM main where Username='$user' AND Password='$pass' AND Role='$role'");
if(mysqli_num_rows($result)===1){
    if($role=="A")
    {
        echo '<script>alert("Success");window.location.href="maina.html";</script>';  
    }
    elseif($role=="W")
    {
        echo '<script>alert("Success");window.location.href="mainw.html";</script>';  
    }
    else
    {
        echo '<script>alert("Success");window.location.href="mainu.php";</script>';  
    }
}
else{
    echo '<script>alert("Not Found!")</script>';
}
}
?>