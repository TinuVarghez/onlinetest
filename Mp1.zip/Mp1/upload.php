<?php
include_once("config.php");
$result = mysqli_query($mysqli, "SELECT * FROM appoint where STest!=''");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Main</title>
    <link rel="stylesheet" type="text/css" href="main.css">
</head>
<body>
   <div class="container">
    <div class="navigation">
       <ul>
        <li>
            <a href="">
                <span class="title">&nbsp;&nbsp;&nbsp;Online Test Appointment & Results</span>
            </a>
        </li>
        <li>
            <a href="">
                <span class="icon"></span>
            </a>
        </li>
        <li class="active">
            <a href="">
                <span class="icon"><ion-icon name="cloud-upload-outline"></ion-icon></span>
                <span class="title">Upload TR</span>
            </a>
        </li>
        <li>
            <a href="updatew.php">
                <span class="icon"><ion-icon name="bag-add-outline"></ion-icon></span>
                <span class="title">Update Key</span>
            </a>
        </li>
        <li>
            <a onclick="signout()">
                <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                <span class="title">Sign Out</span>
            </a>
        </li>
       </ul> 
    </div>
   </div>
   <div class="main">
    <div class="user">
    <img src="images/work.png">
    </div>
    </div>
    <div class="header_fixed">
    <h4>Pending User</h4>
    <table>
    <thead>
        <tr>
            <th>Name</th><th>Age</th><th>Gender</th><th>Date</th><th>Upload Data</th>
        </tr>
    </thead>
    <tbody>
        <?php
        while($user_data = mysqli_fetch_array($result)) 
        {
            echo "<tr>";
            echo "<td>".$user_data['Name']."</td>";
            echo "<td>".$user_data['Age']."</td>";
            echo "<td>".$user_data['Gender']."</td>";
            echo "<td>".$user_data['Date']."</td>";
            echo "<td><a href='edit.php?id=$user_data[Tid]&st=$user_data[STest]&cr=$user_data[Creator]'><ion-icon name='pencil'></ion-icon></a></td>";
        }
        ?>
    </tbody>
        </table>
    </div>
   <script type="module" src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js"></script>
<script>
    let list =document.querySelectorAll('.navigation li');
    function al()
    {
        list.forEach((item)=>
        item.classList.remove('hovered'));
        this.classList.add('hovered')
        list.forEach((item)=>
        item.addEventListener('mouseover',al));
    }
    function signout() {
    let text = "Are u sure!";
    if (confirm(text) == true) {
        window.location.href="login.php";
    }
    }
</script>
</body>
</html>